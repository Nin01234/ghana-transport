"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Navigation } from "@/components/navigation"
import { AuthGuard } from "@/components/auth-guard"
import { ModernMap } from "@/components/modern-map"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  MapPin,
  Users,
  NavigationIcon,
  AlertTriangle,
  CheckCircle,
  Bus,
  Search,
  RefreshCw,
  Phone,
  MessageSquare,
  Clock,
  Zap,
  User,
  Star,
  Wifi,
  Shield,
} from "lucide-react"

interface LiveBus {
  id: string
  busNumber: string
  route: string
  currentLocation: string
  nextStop: string
  eta: string
  occupancy: number
  maxCapacity: number
  status: "on-time" | "delayed" | "arrived" | "boarding"
  speed: number
  progress: number
  driver: {
    name: string
    phone: string
    rating: number
    avatar: string
  }
  coordinates: [number, number]
  lastUpdate: Date
  amenities: string[]
  temperature: number
  wifiStrength: number
}

const liveBuses: LiveBus[] = [
  {
    id: "1",
    busNumber: "GT-001",
    route: "Accra → Kumasi",
    currentLocation: "Nsawam",
    nextStop: "Suhum",
    eta: "15 mins",
    occupancy: 32,
    maxCapacity: 45,
    status: "on-time",
    speed: 65,
    progress: 35,
    driver: {
      name: "Kwame Asante",
      phone: "+233509921758",
      rating: 4.8,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    coordinates: [-0.3518, 5.8089],
    lastUpdate: new Date(Date.now() - 1000 * 60 * 2),
    amenities: ["WiFi", "AC", "Charging Port", "Refreshments"],
    temperature: 22,
    wifiStrength: 85,
  },
  {
    id: "2",
    busNumber: "GT-002",
    route: "Accra → Tamale",
    currentLocation: "Kumasi",
    nextStop: "Techiman",
    eta: "45 mins",
    occupancy: 38,
    maxCapacity: 50,
    status: "delayed",
    speed: 45,
    progress: 60,
    driver: {
      name: "Ama Serwaa",
      phone: "+233509921758",
      rating: 4.6,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    coordinates: [-1.6244, 6.6885],
    lastUpdate: new Date(Date.now() - 1000 * 60 * 5),
    amenities: ["WiFi", "AC", "Meals", "Entertainment"],
    temperature: 24,
    wifiStrength: 92,
  },
  {
    id: "3",
    busNumber: "GT-003",
    route: "Accra → Cape Coast",
    currentLocation: "Cape Coast Station",
    nextStop: "Arrived",
    eta: "Arrived",
    occupancy: 0,
    maxCapacity: 40,
    status: "arrived",
    speed: 0,
    progress: 100,
    driver: {
      name: "Kofi Mensah",
      phone: "+233509921758",
      rating: 4.9,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    coordinates: [-1.2466, 5.1053],
    lastUpdate: new Date(Date.now() - 1000 * 60 * 10),
    amenities: ["AC", "Charging Port"],
    temperature: 21,
    wifiStrength: 78,
  },
]

export default function TrackingPage() {
  const { toast } = useToast()
  const [buses, setBuses] = useState<LiveBus[]>(liveBuses)
  const [selectedBus, setSelectedBus] = useState<LiveBus | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [lastUpdated, setLastUpdated] = useState(new Date())
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [callDialogOpen, setCallDialogOpen] = useState(false)
  const [messageDialogOpen, setMessageDialogOpen] = useState(false)
  const [message, setMessage] = useState("")

  useEffect(() => {
    if (!autoRefresh) return

    const interval = setInterval(() => {
      setLastUpdated(new Date())
      setBuses((prevBuses) =>
        prevBuses.map((bus) => ({
          ...bus,
          progress: Math.min(100, bus.progress + Math.random() * 2),
          speed: bus.status === "arrived" ? 0 : 45 + Math.random() * 30,
          lastUpdate: new Date(),
          occupancy: Math.max(0, bus.occupancy + Math.floor(Math.random() * 3 - 1)),
          wifiStrength: Math.max(60, Math.min(100, bus.wifiStrength + Math.floor(Math.random() * 10 - 5))),
        })),
      )
    }, 10000)

    return () => clearInterval(interval)
  }, [autoRefresh])

  const filteredBuses = buses.filter((bus) => {
    const matchesSearch =
      bus.busNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bus.route.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bus.currentLocation.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = filterStatus === "all" || bus.status === filterStatus

    return matchesSearch && matchesStatus
  })

  const handleCall = (bus: LiveBus) => {
    setSelectedBus(bus)
    setCallDialogOpen(true)
  }

  const makeCall = () => {
    if (selectedBus) {
      window.open(`tel:${selectedBus.driver.phone}`, "_self")
      toast({
        title: "Calling Driver",
        description: `Calling ${selectedBus.driver.name} at ${selectedBus.driver.phone}`,
      })
      setCallDialogOpen(false)
    }
  }

  const handleMessage = (bus: LiveBus) => {
    setSelectedBus(bus)
    setMessageDialogOpen(true)
  }

  const sendMessage = () => {
    if (selectedBus && message.trim()) {
      // In real implementation, this would send SMS via API
      const smsUrl = `sms:${selectedBus.driver.phone}?body=${encodeURIComponent(message)}`
      window.open(smsUrl, "_self")

      toast({
        title: "Message Sent",
        description: `Message sent to ${selectedBus.driver.name}`,
      })
      setMessage("")
      setMessageDialogOpen(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "on-time":
        return "bg-green-100 text-green-800 border-green-200"
      case "delayed":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "arrived":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "boarding":
        return "bg-purple-100 text-purple-800 border-purple-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "on-time":
        return <CheckCircle className="h-4 w-4" />
      case "delayed":
        return <AlertTriangle className="h-4 w-4" />
      case "arrived":
        return <MapPin className="h-4 w-4" />
      case "boarding":
        return <Users className="h-4 w-4" />
      default:
        return <Bus className="h-4 w-4" />
    }
  }

  const formatLastUpdate = (date: Date) => {
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / (1000 * 60))

    if (minutes < 1) return "Just now"
    if (minutes < 60) return `${minutes}m ago`
    return `${Math.floor(minutes / 60)}h ago`
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <Navigation />

        <div className="container py-6">
          {/* Enhanced Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-ghana-green via-ghana-gold to-ghana-red bg-clip-text text-transparent">
                  Live Bus Tracking
                </h1>
                <p className="text-lg text-muted-foreground">Real-time GPS tracking across Ghana</p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground bg-white/80 backdrop-blur-sm rounded-full px-4 py-2 shadow-sm">
                  <div
                    className={`w-2 h-2 rounded-full ${autoRefresh ? "bg-green-500 animate-pulse" : "bg-gray-400"}`}
                  ></div>
                  <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setAutoRefresh(!autoRefresh)}
                  className="bg-white/80 backdrop-blur-sm hover:bg-white"
                >
                  {autoRefresh ? "Pause" : "Resume"} Auto-refresh
                </Button>
              </div>
            </div>

            {/* Enhanced Search and Filters */}
            <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="Search by bus number, route, or location..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 bg-white/50 border-ghana-green/20 focus:border-ghana-green"
                      />
                    </div>
                  </div>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-full sm:w-48 bg-white/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="on-time">On Time</SelectItem>
                      <SelectItem value="delayed">Delayed</SelectItem>
                      <SelectItem value="boarding">Boarding</SelectItem>
                      <SelectItem value="arrived">Arrived</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    onClick={() => setLastUpdated(new Date())}
                    className="bg-ghana-green text-white hover:bg-ghana-green/90 border-0"
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Refresh
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            {/* Enhanced Bus List */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">{filteredBuses.length} buses tracked</h2>
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    {buses.filter((b) => b.status === "on-time").length} On Time
                  </Badge>
                  <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                    {buses.filter((b) => b.status === "delayed").length} Delayed
                  </Badge>
                </div>
              </div>

              {filteredBuses.map((bus) => (
                <Card
                  key={bus.id}
                  className={`cursor-pointer transition-all duration-300 hover:shadow-2xl hover:scale-[1.02] bg-white/90 backdrop-blur-sm border-0 ${
                    selectedBus?.id === bus.id ? "ring-2 ring-ghana-green shadow-xl scale-[1.02]" : ""
                  }`}
                  onClick={() => setSelectedBus(bus)}
                >
                  <CardContent className="p-6">
                    {/* Bus Header */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <div className="h-12 w-12 rounded-full bg-gradient-to-r from-ghana-green to-ghana-gold flex items-center justify-center text-white font-bold">
                            {bus.busNumber.split("-")[1]}
                          </div>
                          <div>
                            <h3 className="font-semibold text-xl">{bus.busNumber}</h3>
                            <p className="text-muted-foreground font-medium">{bus.route}</p>
                          </div>
                          <Badge className={getStatusColor(bus.status)}>
                            {getStatusIcon(bus.status)}
                            <span className="ml-1 capitalize">{bus.status.replace("-", " ")}</span>
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-2 mb-1">
                          <Zap className="h-4 w-4 text-ghana-green" />
                          <span className="text-lg font-semibold">{Math.round(bus.speed)} km/h</span>
                        </div>
                        <div className="text-sm text-muted-foreground">ETA: {bus.eta}</div>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-muted-foreground">Journey Progress</span>
                        <span className="font-medium">{Math.round(bus.progress)}%</span>
                      </div>
                      <Progress value={bus.progress} className="h-3 bg-gray-200">
                        <div
                          className="h-full bg-gradient-to-r from-ghana-green to-ghana-gold rounded-full transition-all duration-500"
                          style={{ width: `${bus.progress}%` }}
                        />
                      </Progress>
                    </div>

                    {/* Location Info */}
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <div className="text-sm font-medium">{bus.currentLocation}</div>
                          <div className="text-xs text-muted-foreground">Current location</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <NavigationIcon className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <div className="text-sm font-medium">{bus.nextStop}</div>
                          <div className="text-xs text-muted-foreground">Next stop</div>
                        </div>
                      </div>
                    </div>

                    {/* Amenities and Stats */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {bus.amenities.map((amenity) => (
                        <Badge key={amenity} variant="secondary" className="text-xs bg-ghana-green/10 text-ghana-green">
                          {amenity === "WiFi" && <Wifi className="mr-1 h-3 w-3" />}
                          {amenity === "AC" && <Zap className="mr-1 h-3 w-3" />}
                          {amenity}
                        </Badge>
                      ))}
                      <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                        {bus.temperature}°C
                      </Badge>
                      <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
                        WiFi {bus.wifiStrength}%
                      </Badge>
                    </div>

                    {/* Bottom Actions */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium">
                            {bus.occupancy}/{bus.maxCapacity}
                          </span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{formatLastUpdate(bus.lastUpdate)}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleCall(bus)
                          }}
                          className="bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
                        >
                          <Phone className="mr-1 h-3 w-3" />
                          Call
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleMessage(bus)
                          }}
                          className="bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                        >
                          <MessageSquare className="mr-1 h-3 w-3" />
                          Message
                        </Button>
                      </div>
                    </div>

                    {/* Occupancy Visualization */}
                    <div className="mt-4">
                      <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                        <span>Occupancy</span>
                        <span>{Math.round((bus.occupancy / bus.maxCapacity) * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full transition-all ${
                            (bus.occupancy / bus.maxCapacity) >= 0.9
                              ? "bg-red-500"
                              : bus.occupancy / bus.maxCapacity >= 0.7
                                ? "bg-yellow-500"
                                : "bg-green-500"
                          }`}
                          style={{ width: `${(bus.occupancy / bus.maxCapacity) * 100}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Enhanced Sidebar */}
            <div className="space-y-6">
              {/* Live Map */}
              <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MapPin className="mr-2 h-5 w-5 text-ghana-green" />
                    Live Map
                  </CardTitle>
                  <CardDescription>Real-time bus locations across Ghana</CardDescription>
                </CardHeader>
                <CardContent>
                  <ModernMap
                    locations={filteredBuses.map((bus) => ({
                      id: bus.id,
                      name: bus.busNumber,
                      coordinates: bus.coordinates,
                      type: "bus" as const,
                      status: bus.status,
                    }))}
                    onLocationSelect={(location) => {
                      const bus = filteredBuses.find((b) => b.id === location.id)
                      if (bus) setSelectedBus(bus)
                    }}
                    showUserLocation={true}
                  />
                </CardContent>
              </Card>

              {/* Selected Bus Details */}
              {selectedBus && (
                <Card className="border-ghana-green bg-gradient-to-br from-white to-ghana-green/5 shadow-xl">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Bus className="mr-2 h-5 w-5 text-ghana-green" />
                      Bus Details
                    </CardTitle>
                    <CardDescription>
                      {selectedBus.busNumber} - {selectedBus.route}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Status</span>
                        <Badge className={getStatusColor(selectedBus.status)}>
                          {getStatusIcon(selectedBus.status)}
                          <span className="ml-1 capitalize">{selectedBus.status.replace("-", " ")}</span>
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Current Location</span>
                        <span className="text-sm font-medium">{selectedBus.currentLocation}</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Next Stop</span>
                        <span className="text-sm font-medium">{selectedBus.nextStop}</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">ETA</span>
                        <span className="text-sm font-medium">{selectedBus.eta}</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Speed</span>
                        <span className="text-sm font-medium">{Math.round(selectedBus.speed)} km/h</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Temperature</span>
                        <span className="text-sm font-medium">{selectedBus.temperature}°C</span>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-medium mb-3 flex items-center">
                        <User className="mr-2 h-4 w-4" />
                        Driver Information
                      </h4>
                      <div className="flex items-center space-x-3 mb-3">
                        <img
                          src={selectedBus.driver.avatar || "/placeholder.svg"}
                          alt={selectedBus.driver.name}
                          className="w-10 h-10 rounded-full"
                        />
                        <div>
                          <div className="font-medium">{selectedBus.driver.name}</div>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400 mr-1" />
                            {selectedBus.driver.rating}
                          </div>
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          className="flex-1 bg-green-600 hover:bg-green-700"
                          onClick={() => handleCall(selectedBus)}
                        >
                          <Phone className="mr-2 h-4 w-4" />
                          Call Driver
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={() => handleMessage(selectedBus)}
                        >
                          <MessageSquare className="mr-2 h-4 w-4" />
                          Message
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* System Status */}
              <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-green-700 flex items-center">
                    <Shield className="mr-2 h-5 w-5" />
                    System Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-700">GPS Tracking</span>
                    <Badge className="bg-green-100 text-green-800">Online</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-700">Real-time Updates</span>
                    <Badge className="bg-green-100 text-green-800">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-700">Communication</span>
                    <Badge className="bg-green-100 text-green-800">Connected</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-700">Support Available</span>
                    <Badge className="bg-green-100 text-green-800">24/7</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Call Dialog */}
        <Dialog open={callDialogOpen} onOpenChange={setCallDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Call Driver</DialogTitle>
              <DialogDescription>You're about to call {selectedBus?.driver.name}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex items-center space-x-4 p-4 bg-muted rounded-lg">
                <img
                  src={selectedBus?.driver.avatar || "/placeholder.svg"}
                  alt={selectedBus?.driver.name}
                  className="w-12 h-12 rounded-full"
                />
                <div>
                  <div className="font-medium">{selectedBus?.driver.name}</div>
                  <div className="text-sm text-muted-foreground">{selectedBus?.driver.phone}</div>
                  <div className="flex items-center text-sm">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400 mr-1" />
                    {selectedBus?.driver.rating} rating
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setCallDialogOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={makeCall} className="flex-1 bg-green-600 hover:bg-green-700">
                  <Phone className="mr-2 h-4 w-4" />
                  Call Now
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Message Dialog */}
        <Dialog open={messageDialogOpen} onOpenChange={setMessageDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Send Message</DialogTitle>
              <DialogDescription>Send a message to {selectedBus?.driver.name}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex items-center space-x-4 p-4 bg-muted rounded-lg">
                <img
                  src={selectedBus?.driver.avatar || "/placeholder.svg"}
                  alt={selectedBus?.driver.name}
                  className="w-12 h-12 rounded-full"
                />
                <div>
                  <div className="font-medium">{selectedBus?.driver.name}</div>
                  <div className="text-sm text-muted-foreground">{selectedBus?.driver.phone}</div>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Message</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message here..."
                  className="w-full mt-1 p-3 border rounded-md resize-none h-24"
                />
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setMessageDialogOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={sendMessage} disabled={!message.trim()} className="flex-1">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Send Message
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </AuthGuard>
  )
}

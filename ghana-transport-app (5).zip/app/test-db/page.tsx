"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/components/auth-provider"
import { supabase } from "@/lib/supabase"
import { CheckCircle, XCircle, Database, Users, Loader2 } from "lucide-react"

interface TestResult {
  name: string
  status: "success" | "error" | "loading"
  message: string
  data?: any
}

export default function TestDatabasePage() {
  const { user } = useAuth()
  const [tests, setTests] = useState<TestResult[]>([])
  const [isRunning, setIsRunning] = useState(false)

  const updateTest = (name: string, status: TestResult["status"], message: string, data?: any) => {
    setTests((prev) => {
      const existing = prev.find((t) => t.name === name)
      if (existing) {
        existing.status = status
        existing.message = message
        existing.data = data
        return [...prev]
      } else {
        return [...prev, { name, status, message, data }]
      }
    })
  }

  const runTests = async () => {
    setIsRunning(true)
    setTests([])

    // Test 1: Database Connection
    updateTest("Database Connection", "loading", "Testing connection...")
    try {
      const { data, error } = await supabase.from("profiles").select("count").limit(1)
      if (error) throw error
      updateTest("Database Connection", "success", "Successfully connected to Supabase")
    } catch (error: any) {
      updateTest("Database Connection", "error", `Connection failed: ${error.message}`)
    }

    // Test 2: Authentication
    updateTest("Authentication", "loading", "Checking authentication...")
    try {
      const {
        data: { session },
        error,
      } = await supabase.auth.getSession()
      if (error) throw error
      if (session?.user) {
        updateTest("Authentication", "success", `Authenticated as ${session.user.email}`)
      } else {
        updateTest("Authentication", "error", "No active session")
      }
    } catch (error: any) {
      updateTest("Authentication", "error", `Auth check failed: ${error.message}`)
    }

    // Test 3: Profile Creation/Retrieval
    if (user) {
      updateTest("User Profile", "loading", "Checking user profile...")
      try {
        const { data, error } = await supabase.from("profiles").select("*").eq("id", user.id).single()

        if (error && error.code === "PGRST116") {
          // Profile doesn't exist, try to create it
          const { error: insertError } = await supabase.from("profiles").insert({
            id: user.id,
            email: user.email!,
            full_name: user.user_metadata?.full_name || null,
          })

          if (insertError) throw insertError
          updateTest("User Profile", "success", "Profile created successfully")
        } else if (error) {
          throw error
        } else {
          updateTest("User Profile", "success", "Profile retrieved successfully", data)
        }
      } catch (error: any) {
        updateTest("User Profile", "error", `Profile error: ${error.message}`)
      }
    }

    // Test 4: Routes Table
    updateTest("Routes Data", "loading", "Fetching routes...")
    try {
      const { data, error } = await supabase.from("routes").select("*").limit(5)

      if (error) throw error
      updateTest("Routes Data", "success", `Found ${data.length} routes`, data)
    } catch (error: any) {
      updateTest("Routes Data", "error", `Routes fetch failed: ${error.message}`)
    }

    // Test 5: Bus Operators
    updateTest("Bus Operators", "loading", "Fetching operators...")
    try {
      const { data, error } = await supabase.from("bus_operators").select("*").limit(5)

      if (error) throw error
      updateTest("Bus Operators", "success", `Found ${data.length} operators`, data)
    } catch (error: any) {
      updateTest("Bus Operators", "error", `Operators fetch failed: ${error.message}`)
    }

    // Test 6: Buses
    updateTest("Buses Data", "loading", "Fetching buses...")
    try {
      const { data, error } = await supabase
        .from("buses")
        .select(`
          *,
          bus_operators(name),
          routes(name, origin, destination)
        `)
        .limit(5)

      if (error) throw error
      updateTest("Buses Data", "success", `Found ${data.length} buses with relations`, data)
    } catch (error: any) {
      updateTest("Buses Data", "error", `Buses fetch failed: ${error.message}`)
    }

    // Test 7: User Stats Function
    if (user) {
      updateTest("User Stats Function", "loading", "Testing user stats function...")
      try {
        const { data, error } = await supabase.rpc("get_user_stats", { user_uuid: user.id })

        if (error) throw error
        updateTest("User Stats Function", "success", "Stats function working", data)
      } catch (error: any) {
        updateTest("User Stats Function", "error", `Stats function failed: ${error.message}`)
      }
    }

    // Test 8: RLS Policies
    updateTest("Row Level Security", "loading", "Testing RLS policies...")
    try {
      // Try to access another user's profile (should fail)
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .neq("id", user?.id || "00000000-0000-0000-0000-000000000000")
        .limit(1)

      if (data && data.length === 0) {
        updateTest("Row Level Security", "success", "RLS policies are working correctly")
      } else {
        updateTest("Row Level Security", "error", "RLS policies may not be working")
      }
    } catch (error: any) {
      updateTest("Row Level Security", "error", `RLS test failed: ${error.message}`)
    }

    setIsRunning(false)
  }

  const getStatusIcon = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-600" />
      case "error":
        return <XCircle className="h-5 w-5 text-red-600" />
      case "loading":
        return <Loader2 className="h-5 w-5 text-blue-600 animate-spin" />
    }
  }

  const getStatusColor = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return "bg-green-100 text-green-800 border-green-200"
      case "error":
        return "bg-red-100 text-red-800 border-red-200"
      case "loading":
        return "bg-blue-100 text-blue-800 border-blue-200"
    }
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="container max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Database & Authentication Test</h1>
          <p className="text-muted-foreground">
            Test the Supabase connection, authentication, and database functionality
          </p>
        </div>

        <div className="mb-6">
          <Button onClick={runTests} disabled={isRunning} size="lg">
            {isRunning ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Running Tests...
              </>
            ) : (
              <>
                <Database className="mr-2 h-4 w-4" />
                Run Database Tests
              </>
            )}
          </Button>
        </div>

        {user && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="mr-2 h-5 w-5" />
                Current User
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p>
                  <strong>ID:</strong> {user.id}
                </p>
                <p>
                  <strong>Email:</strong> {user.email}
                </p>
                <p>
                  <strong>Email Confirmed:</strong> {user.email_confirmed_at ? "Yes" : "No"}
                </p>
                <p>
                  <strong>Created:</strong> {new Date(user.created_at).toLocaleString()}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="space-y-4">
          {tests.map((test, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(test.status)}
                    <span>{test.name}</span>
                  </div>
                  <Badge className={getStatusColor(test.status)}>{test.status.toUpperCase()}</Badge>
                </CardTitle>
                <CardDescription>{test.message}</CardDescription>
              </CardHeader>
              {test.data && (
                <CardContent>
                  <details className="cursor-pointer">
                    <summary className="font-medium mb-2">View Data</summary>
                    <pre className="bg-muted p-4 rounded-lg text-sm overflow-auto">
                      {JSON.stringify(test.data, null, 2)}
                    </pre>
                  </details>
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        {tests.length === 0 && !isRunning && (
          <Card>
            <CardContent className="text-center py-12">
              <Database className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Ready to Test</h3>
              <p className="text-muted-foreground">Click "Run Database Tests" to verify your Supabase setup</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
